## Putting the pretrained checkpoint in this folder

1. The pretrained checkpoint of BL can be obtained at [BL_release.pt](https://drive.google.com/file/d/1pXjXAIItViTFs7qUBY-b11WY50mzoVM2/view). 

2. The pretrained checkpoint of MT-E can be obtained at [MT-E_release.pt](https://drive.google.com/open?id=1eEMH2wTz2bFDkpgTFpSmzdoJRTnOparJ).

3. The pretrained checkpoint of MT-A can be obtained at [MT-A_release.pt](https://drive.google.com/open?id=1j0GmSgfzkB0gYu4zLVXCrlv3b3J20eOv).

4. The pretrained checkpoint of MT-S can be obtained at [MT-S_release.pt](https://drive.google.com/open?id=16m_N1neg6aDST1OqwrQRxNd-Z70_SU4o).